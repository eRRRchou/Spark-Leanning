package code
object Demo {
  def main(args: Array[String]): Unit = {
    val arr = Array(1,2,3,4,5)
    arr.map(Array(_).map(_+10))
    println(arr.toBuffer)
  }
}
